import ProductFacts from "./ProductFacts";
import QtyInput from "./QtyInput";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import ProductVisual from "./ProductVisual";
import { peso } from "../utils/format";
import { useAuth } from "../context/AuthContext";
import { useCart, bulkDiscountRate } from "../context/CartContext";
import { useToast } from "../context/ToastContext";
import { useUI } from "../context/UIContext";
import ProductCard from "./ProductCard";
import ReviewSection from "./reviews/ReviewSection";
import PriceTag from "./PriceTag";
import OrderConfirmModal from "./OrderConfirmModal";
import { priceLine } from "../utils/pricing";
import StarRating from "./reviews/StarRating";

export default function ProductModal({ product, onClose, allProducts = [], onSelectProduct }) {
  const { user } = useAuth();
  const { addItem, startDirect } = useCart();
  const showToast = useToast();
  const navigate = useNavigate();
  const { requireLogin } = useUI();
  const [qty, setQty] = useState(1);
  const [confirming, setConfirming] = useState(null); // "cart" | "buy" | null
  const [confirmBusy, setConfirmBusy] = useState(false);

  if (!product) return null;

  const priced = priceLine(product.price, qty, product.salePercent);
  const rate = priced.rate;
  const discountedUnit = priced.unitPrice;
  const saleBeatsBulk = product.onSale && product.salePercent / 100 >= bulkDiscountRate(qty);
  const nextTier = qty < 5 ? 5 : qty < 10 ? 10 : 20;

  const returnTo = `/shop?product=${product.id}`;

  function handleAddToCart() {
    if (!user) { requireLogin("login"); return; }
    setConfirming("cart");
  }

  function handleBuyNow() {
    if (!user) { requireLogin("login"); return; }
    setConfirming("buy");
  }

  // Runs only after the customer confirms in the dialog. Buy Now is its own purchase and never changes the cart.
  async function confirmPurchase(pieces) {
    if (confirmBusy) return;
    if (confirming === "buy") {
      startDirect(product, pieces);
      setConfirming(null);
      onClose();
      navigate("/checkout");
      return;
    }
    setConfirmBusy(true);
    try {
      if (await addItem(product, pieces)) {
        setConfirming(null);
        showToast("Added to cart", "success");
        onClose();
      }
    } finally {
      setConfirmBusy(false);
    }
  }

  return (
    <div className="overlay" onClick={onClose}>
      {confirming && (
        <OrderConfirmModal product={product} initialQty={qty} mode={confirming} busy={confirmBusy}
          onCancel={() => setConfirming(null)} onConfirm={confirmPurchase} />
      )}
      <div className="modal wide" onClick={(e) => e.stopPropagation()}>
        <div className="modal-head">
          <h3>Product Details</h3>
          <button className="modal-close" onClick={onClose}>&times;</button>
        </div>
        <div className="modal-body">
          <div className="pd-grid">
            <div>
              <div className="pd-visual">
                <ProductVisual product={product} widthPercent={44} />
              </div>
              <ProductFacts product={product} />
              <div className="pd-extra">
                <h4 className="pd-extra-head">Bulk Pricing - Buy More, Save More</h4>
                <div className="bulk-tiers">
                  <div className="bulk-tier"><span>5-9 units</span><span>5% off</span></div>
                  <div className="bulk-tier"><span>10-19 units</span><span>10% off</span></div>
                  <div className="bulk-tier"><span>20+ units</span><span>15% off</span></div>
                </div>
                <p className="field-hint">Free shipping automatically applies on orders of &#8369;1,500+ or 10+ total items.</p>
              </div>

            </div>
            <div>
              <span className="product-cat">{product.category}</span>
              <h2 style={{ margin: "6px 0 4px" }}>{product.name}</h2>
              <div className="pd-price" aria-label="Price">
                <span className="pd-price-now">{peso(product.onSale ? product.salePrice : product.price)}</span>
                {product.onSale && <span className="pd-price-was">{peso(product.price)}</span>}
              </div>
              {product.reviews > 0 ? (
                <span className="product-rating">
                  <StarRating value={product.rating} size={14} /> {product.rating.toFixed(1)} &middot; {product.reviews} review{product.reviews === 1 ? "" : "s"}
                </span>
              ) : (
                <span className="product-rating">No reviews yet</span>
              )}
              <span className={`stock-count ${product.stock < 20 ? "low" : ""}`} style={{ display: "block", marginTop: 4 }}>
                {product.stock > 0 ? `${product.stock} units available` : "Out of stock"}
              </span>
              {user ? (
                <>
                  <div className="pd-qty">
                    <QtyInput value={qty} onCommit={setQty} max={product.stock} packSize={product.packSize} />
                  </div>
                  <p className="field-hint" style={{ marginTop: -8, marginBottom: 14 }}>
                    {rate > 0
                      ? <span style={{ color: "var(--ok-text)", fontWeight: 600 }}>{Math.round(rate * 100)}% {saleBeatsBulk ? "sale" : "bulk"} discount applied - {peso(discountedUnit)} per unit &middot; {peso(priced.lineTotal)} total</span>
                      : qty < 20 ? `Buy ${nextTier - qty} more to unlock a bulk discount` : ""}
                  </p>
                  <div className="flex gap-12">
                    <button className="btn btn-outline btn-block" disabled={product.stock === 0} onClick={handleAddToCart}>Add to Cart</button>
                    <button className="btn btn-primary btn-block" disabled={product.stock === 0} onClick={handleBuyNow}>Buy Now</button>
                  </div>
                </>
              ) : (
                <>
                  <div className="alert alert-info" style={{ marginTop: 16 }}>
                    Log in or create a free account to add this item to your cart or buy it now.
                  </div>
                  <div className="flex gap-12">
                    <button className="btn btn-outline btn-block" onClick={() => { onClose(); requireLogin("login", null, returnTo); }}>Log In</button>
                    <button className="btn btn-primary btn-block" onClick={() => { onClose(); requireLogin("register", null, returnTo); }}>Create Account</button>
                  </div>
                </>
              )}
              <p style={{ marginTop: 14, color: "var(--muted)" }}>{product.description}</p>


              {product.benefits?.length > 0 && (
                <div className="pd-extra">
                  <h4 className="pd-extra-head">Key Benefits</h4>
                  <ul className="pd-specs">
                    {product.benefits.map((b, i) => <li key={i}>{b}</li>)}
                  </ul>
                </div>
              )}

              {product.usage?.length > 0 && (
                <div className="pd-extra">
                  <h4 className="pd-extra-head">How to Use</h4>
                  <ol className="pd-specs" style={{ paddingLeft: 18 }}>
                    {product.usage.map((u, i) => <li key={i} style={{ listStyle: "decimal" }}>{u}</li>)}
                  </ol>
                </div>
              )}

              <div className="pd-extra pd-shipping">
                <div>Metro Manila: 1-2 business days &middot; Provincial: 3-5 business days</div>
                <div>7-day return &middot; 30-day defect replacement &middot; Rainchem-verified product</div>
              </div>

              <div style={{ marginTop: 6 }}><PriceTag product={product} size={26} /></div>
              {product.onSale && (
                <p className="field-hint" style={{ margin: "4px 0 0" }}>
                  {product.saleLabel ? `${product.saleLabel}. ` : ""}Sale until {new Date(product.saleEndDate + "T00:00:00").toLocaleDateString("en-PH", { month: "short", day: "numeric" })}.
                  {" "}Sale and bulk discounts do not stack; you get the bigger one.
                </p>
              )}

                    </div>
          </div>

          {allProducts.filter((p) => p.category === product.category && p.id !== product.id).length > 0 && (
            <div className="pd-reco">
              <h4 className="pd-extra-head">You may also like</h4>
              <div className="product-row">
                {allProducts
                  .filter((p) => p.category === product.category && p.id !== product.id)
                  .slice(0, 8)
                  .map((p) => (
                    <div className="product-row-item" key={p.id}>
                      <ProductCard product={p} onOpen={onSelectProduct || (() => {})} />
                    </div>
                  ))}
              </div>
            </div>
          )}

          <ReviewSection key={product.id} productId={product.id} onNavigate={onClose} />
        </div>
      </div>
    </div>
  );
}
